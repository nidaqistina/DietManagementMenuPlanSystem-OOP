import java.util.ArrayList;

public abstract class Meal {
    protected String name;
    protected double calories;
    protected double fat;
    protected double carb;
    protected double protein;
    protected ArrayList<String> ingredients;

    public Meal(String name, double calories, double fat, double carb, double protein, ArrayList<String> ingredients) {
        this.name = name;
        this.calories = calories;
        this.fat = fat;
        this.carb = carb;
        this.protein = protein;
        this.ingredients = ingredients;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    public double getCarb() {
        return carb;
    }

    public void setCarb(double carb) {
        this.carb = carb;
    }

    public double getProtein() {
        return protein;
    }

    public void setProtein(double protein) {
        this.protein = protein;
    }

    public void addIngredient(String ingredient) {
        this.ingredients.add(ingredient);
    }

    public abstract void displayMeal();

    public boolean containsAllergen(HealthCondition healthCondition) {
        if (healthCondition == null) {
            return false; // No health condition, hence no allergens
        }
        for (String ingredient : ingredients) {
            if (healthCondition.contains(ingredient)) {
                return true;
            }
        }
        return false;
    }
}
