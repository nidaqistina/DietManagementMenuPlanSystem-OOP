import java.util.ArrayList;

public class Dinner extends Meal {
    public Dinner(String name, double calories, double fat, double carb, double protein, ArrayList<String> ingredients) {
        super(name, calories, fat, carb, protein, ingredients);
    }

    @Override
    public void displayMeal() {
        System.out.println("\nDinner: " + name);
        System.out.println("Calories: " + calories);
        System.out.println("Fat: " + fat);
        System.out.println("Carb: " + carb);
        System.out.println("Protein: " + protein);
        System.out.println("Ingredients: " + ingredients);
    }
}