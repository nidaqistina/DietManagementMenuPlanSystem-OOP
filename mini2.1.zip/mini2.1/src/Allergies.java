import java.util.*;

public class Allergies implements HealthCondition {
    private List<String> allergens;
    private static final List<String> REGISTERED_ALLERGENS = Arrays.asList(
        "Milk", "Egg", "Honey", "Cheese", "Ground Beef", "Parmesan Cheese",
        "Cheddar Cheese", "Pepperoni", "Tomato Sauce", "Tahini Sauce", "Beans",
        "Mayonnaise", "Peanut Butter", "Broccoli", "Beef"
    );

    public Allergies() {
        this.allergens = new ArrayList<>();
    }

    public void addAllergen(String allergen) throws UnregisteredAllergyException {
        if (!REGISTERED_ALLERGENS.contains(allergen)) {
            throw new UnregisteredAllergyException("Unregistered allergen: " + allergen);
        }
        this.allergens.add(allergen);
    }

    public List<String> getAllergens() {
        return allergens;
    }

    public static List<String> getRegisteredAllergens() {
        return REGISTERED_ALLERGENS;
    }

    @Override
    public boolean contains(String ingredient) {
        return allergens.contains(ingredient);
    }

    @Override
    public String getDescription() {
        return "Allergies: " + allergens;
    }
}
