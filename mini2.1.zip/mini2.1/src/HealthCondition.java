public interface HealthCondition {
    boolean contains(String ingredient);
    String getDescription();
}