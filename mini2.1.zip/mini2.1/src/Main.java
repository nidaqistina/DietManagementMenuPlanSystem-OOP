import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int continuePlan;

        // Gather user information
        System.out.println("Enter your name: ");
        String name = scanner.nextLine();

        System.out.println("Enter your age: ");
        int age = scanner.nextInt();

        System.out.println("Enter your height (in cm): ");
        double height = scanner.nextDouble();

        System.out.println("Enter your weight (in kg): ");
        double weight = scanner.nextDouble();

        System.out.println("Do you have any health conditions? (yes/no): ");
        String hasHealthCondition = scanner.next().toLowerCase();

        HealthCondition healthCondition = null;
        scanner.nextLine(); // Consume the newline left by nextDouble()

        if (hasHealthCondition.equals("yes")) {
            healthCondition = new Allergies();
            boolean validAllergies = false;

            while (!validAllergies) {
                try {
                    System.out.println("\nRegistered Allergens:");
                    for (String allergen : Allergies.getRegisteredAllergens()) {
                        System.out.println("- " + allergen);
                    }

                    System.out.println("\nEnter your allergies (separate each with a comma), or 'y' to continue if you have no more allergies: ");
                    String[] allergies = scanner.nextLine().split(",");
                    for (String allergen : allergies) {
                        if (allergen.trim().equalsIgnoreCase("y")) {
                            validAllergies = true;
                            break;
                        }
                        ((Allergies) healthCondition).addAllergen(allergen.trim());
                    }
                    validAllergies = true;
                } catch (UnregisteredAllergyException e) {
                    System.out.println(e.getMessage() + " Please enter again");
                }
            }
        }

        PersonInfo person = new PersonInfo(name, age, height, weight, healthCondition);
        System.out.println();
        System.out.println("Person Info:");
        person.displayInfo();
        Menu menu = person.getMenu();
        menu.importMeals();

        do {
            System.out.println("\nChoose an option:");
            System.out.println("1. Get daily meal plan");
            System.out.println("2. Customize your own meal plan");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Select meals ensuring they don't exceed daily calorie intake and contain no
                    // allergens
                    menu.selectMeals(person);
                    break;
                case 2:
                    CustomizeMenu customMenu = new CustomizeMenu(person.getDailyCalorieIntake());
                    customMenu.customizeMealPlan(menu, person);
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
                    break;
            }

            System.out.println("\nDo you want to plan another meal? (1=yes, 2=no): ");
            continuePlan = scanner.nextInt();
            scanner.nextLine(); // consume the remaining newline

        } while (continuePlan == 1);

        scanner.close();
    }
}
