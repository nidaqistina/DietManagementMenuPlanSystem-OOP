public class PersonInfo {
    private String name;
    private int age;
    private double height;
    private double weight;
    private HealthCondition healthCondition;
    private double dailyCalorieIntake;
    private Menu menu;

    public PersonInfo(String name, int age, double height, double weight, HealthCondition healthCondition) {
        this.name = name;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.healthCondition = healthCondition != null ? healthCondition : new NoHealthCondition();
        this.dailyCalorieIntake = calculateDailyCalorieIntake();
        this.menu = new Menu();
    }

    private double calculateDailyCalorieIntake() {
        // Simplified example calculation
        return 10 * weight + 6.25 * height - 5 * age + 5;
    }

     public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }


    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public Menu getMenu() {
        return menu;
    }

    public double getDailyCalorieIntake() {
        return dailyCalorieIntake;
    }

    public HealthCondition getHealthCondition() {
        return healthCondition;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height + " cm");
        System.out.println("Weight: " + weight + " kg");
        System.out.println("Daily Calorie Intake: " + dailyCalorieIntake + " cal");
        System.out.println(healthCondition.getDescription());
    }
}
