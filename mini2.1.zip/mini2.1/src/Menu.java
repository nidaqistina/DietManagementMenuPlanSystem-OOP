import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Menu {
    private ArrayList<Breakfast> breakfastList;
    private ArrayList<Lunch> lunchList;
    private ArrayList<Dinner> dinnerList;

    public Menu() {
        this.breakfastList = new ArrayList<>();
        this.lunchList = new ArrayList<>();
        this.dinnerList = new ArrayList<>();
    }

    public void addBreakfast(Breakfast breakfast) {
        this.breakfastList.add(breakfast);
    }

    public void addLunch(Lunch lunch) {
        this.lunchList.add(lunch);
    }

    public void addDinner(Dinner dinner) {
        this.dinnerList.add(dinner);
    }

    public ArrayList<Breakfast> getBreakfastList() {
        return breakfastList;
    }

    public ArrayList<Lunch> getLunchList() {
        return lunchList;
    }

    public ArrayList<Dinner> getDinnerList() {
        return dinnerList;
    }

    public boolean containsAllergen(HealthCondition healthCondition) {
        for (Breakfast breakfast : breakfastList) {
            if (breakfast.containsAllergen(healthCondition)) {
                return true;
            }
        }
        for (Lunch lunch : lunchList) {
            if (lunch.containsAllergen(healthCondition)) {
                return true;
            }
        }
        for (Dinner dinner : dinnerList) {
            if (dinner.containsAllergen(healthCondition)) {
                return true;
            }
        }
        return false;
    }

    public void importMeals() {
        importMeal("Breakfast.txt", "breakfast");
        importMeal("Lunch.txt", "lunch");
        importMeal("Dinner.txt", "dinner");
    }

    private void importMeal(String fileName, String mealType) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("File " + fileName + " does not exist.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                double calories = Double.parseDouble(parts[1]);
                double fat = Double.parseDouble(parts[2]);
                double carb = Double.parseDouble(parts[3]);
                double protein = Double.parseDouble(parts[4]);
                ArrayList<String> ingredients = new ArrayList<>();
                for (int i = 5; i < parts.length; i++) {
                    ingredients.add(parts[i]);
                }

                switch (mealType) {
                    case "breakfast":
                        addBreakfast(new Breakfast(name, calories, fat, carb, protein, ingredients));
                        break;
                    case "lunch":
                        addLunch(new Lunch(name, calories, fat, carb, protein, ingredients));
                        break;
                    case "dinner":
                        addDinner(new Dinner(name, calories, fat, carb, protein, ingredients));
                        break;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void selectMeals(PersonInfo person) {
        double dailyCalories = person.getDailyCalorieIntake();
        HealthCondition healthCondition = person.getHealthCondition();
        
        double totalCalories = 0;

        for (Breakfast breakfast : breakfastList) {
            if (!breakfast.containsAllergen(healthCondition) && totalCalories + breakfast.getCalories() <= dailyCalories) {
                breakfast.displayMeal();
                totalCalories += breakfast.getCalories();
                break;
            }
        }

        for (Lunch lunch : lunchList) {
            if (!lunch.containsAllergen(healthCondition) && totalCalories + lunch.getCalories() <= dailyCalories) {
                lunch.displayMeal();
                totalCalories += lunch.getCalories();
                break;
            }
        }

        for (Dinner dinner : dinnerList) {
            if (!dinner.containsAllergen(healthCondition) && totalCalories + dinner.getCalories() <= dailyCalories) {
                dinner.displayMeal();
                totalCalories += dinner.getCalories();
                break;
            }
        }
    }
}
