import java.util.ArrayList;
import java.util.Scanner;

public class CustomizeMenu {
    private ArrayList<Meal> customizeMenu;
    private double dailyCalorie;
    private double customizeCalorie;

    public CustomizeMenu(double dailyCalorie) {
        this.customizeMenu = new ArrayList<>();
        this.dailyCalorie = dailyCalorie;
        this.customizeCalorie = 0;
    }

    public void addMeal(Meal meal) {
        this.customizeMenu.add(meal);
        this.customizeCalorie += meal.getCalories();
    }

    public double getCustomizeCalorie() {
        return customizeCalorie;
    }

    public void displayMenu() {
        System.out.println("\nCustomized Menu:");
        for (Meal meal : customizeMenu) {
            System.out.println("- " + meal.getName());
            System.out.println("  Calories: " + meal.getCalories() + " cal");
            System.out.println("  Fat: " + meal.getFat() + " g");
            System.out.println("  Carbohydrates: " + meal.getCarb() + " g");
            System.out.println("  Protein: " + meal.getProtein() + " g");
            System.out.println();
        }
        System.out.println("Total Calories: " + customizeCalorie + " cal");
    }

    public boolean getResult() {
        return customizeCalorie <= dailyCalorie;
    }

    public void customizeMealPlan(Menu menu, PersonInfo person) {
        Scanner scanner = new Scanner(System.in);
        HealthCondition healthCondition = person.getHealthCondition();
        boolean validMealPlan = false;

        while (!validMealPlan) {
            double totalCalories = 0;
            customizeMenu.clear();
            customizeCalorie = 0;

            System.out.println("\nBreakfast menu: \n");
            for (int i = 0; i < menu.getBreakfastList().size(); i++) {
                Breakfast breakfast = menu.getBreakfastList().get(i);
                System.out.println((i + 1) + ". " + breakfast.getName() + " (" + breakfast.getCalories() + " cal)");
            }
            System.out.println("Choose your breakfast:");
            int breakfastChoice = scanner.nextInt() - 1;
            if (breakfastChoice >= 0 && breakfastChoice < menu.getBreakfastList().size()) {
                Breakfast breakfast = menu.getBreakfastList().get(breakfastChoice);
                if (!breakfast.containsAllergen(healthCondition)) {
                    addMeal(breakfast);
                    totalCalories += breakfast.getCalories();
                } else {
                    System.out.println("This meal contains allergens.");
                    continue;
                }
            }
            
            System.out.println("\nLunch menu: \n");
            for (int i = 0; i < menu.getLunchList().size(); i++) {
                Lunch lunch = menu.getLunchList().get(i);
                System.out.println((i + 1) + ". " + lunch.getName() + " (" + lunch.getCalories() + " cal)");
            }
            System.out.println("Choose your lunch:");
            int lunchChoice = scanner.nextInt() - 1;
            if (lunchChoice >= 0 && lunchChoice < menu.getLunchList().size()) {
                Lunch lunch = menu.getLunchList().get(lunchChoice);
                if (!lunch.containsAllergen(healthCondition)) {
                    addMeal(lunch);
                    totalCalories += lunch.getCalories();
                } else {
                    System.out.println("This meal contains allergens.");
                    continue;
                }
            }
            
            System.out.println("\nDinner menu: \n");
            for (int i = 0; i < menu.getDinnerList().size(); i++) {
                Dinner dinner = menu.getDinnerList().get(i);
                System.out.println((i + 1) + ". " + dinner.getName() + " (" + dinner.getCalories() + " cal)");
            }
            System.out.println("Choose your dinner:");
            int dinnerChoice = scanner.nextInt() - 1;
            if (dinnerChoice >= 0 && dinnerChoice < menu.getDinnerList().size()) {
                Dinner dinner = menu.getDinnerList().get(dinnerChoice);
                if (!dinner.containsAllergen(healthCondition)) {
                    addMeal(dinner);
                    totalCalories += dinner.getCalories();
                } else {
                    System.out.println("This meal contains allergens.");
                    continue;
                }
            }

            if (getResult()) {
                validMealPlan = true;
                displayMenu();
                System.out.println("Your customized menu is within the daily calorie limit.");
            } else {
                System.out.println("Your customized menu exceeds the daily calorie limit. Please choose again.");
                System.out.println();
            }
        }
    }
}
