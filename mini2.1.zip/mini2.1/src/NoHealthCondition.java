public class NoHealthCondition implements HealthCondition {
    @Override
    public boolean contains(String ingredient) {
        return false; // No health conditions mean no restrictions
    }

    @Override
    public String getDescription() {
        return "No health conditions";
    }
}