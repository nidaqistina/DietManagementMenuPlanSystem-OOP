public class UnregisteredAllergyException extends Exception {
    public UnregisteredAllergyException(String message) {
        super(message);
    }
}